$readmeCode = @'
import os

readme_content = """# ΔGENESIS | ΔVERIFY (Product 01)

Independent Evidence & Data Integrity Infrastructure

## Overview
ΔVERIFY is an open architecture designed to make digital evidence independently verifiable. We do not manufacture truth; we provide the cryptographic infrastructure to verify the origin, integrity, and authorization of digital data.

## Architecture
The system uses a dual-engine architecture to ensure separation of duties:
- Generation Engine (Rust): Creates a deterministic hash chain (SHA-256) and packages the evidence.
- Verification Engine (Python/FastAPI): An independent web service that recalculates hashes, verifies Ed25519 signatures, and checks trust registries.

## Prerequisites
- Docker Desktop (Running)
- Git Bash (for OpenSSL utilities)

## How to Run (Third-Party Execution)
1. Clone this repository to your local machine.
2. Ensure Docker Desktop is running.
3. Open a terminal in the project root (where docker-compose.yml is located).
4. Build and run the container:
`bash
docker compose -p dverify up --build -d