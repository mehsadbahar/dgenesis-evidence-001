import os
from fastapi import FastAPI, HTTPException, Depends, Header, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from pydantic import BaseModel
from cryptography.hazmat.primitives.asymmetric import ed25519
import json

app = FastAPI(title='VERIFY API', version='1.0.0')
app.add_middleware(SessionMiddleware, secret_key='dgenesis_super_secret_key_123')
templates = Jinja2Templates(directory='templates')

VALID_API_KEYS = {'dv_test_1234567890'}

def run_verification(sig_data, registry, revocation):
    payload = sig_data['payload']
    signature_bytes = bytes.fromhex(sig_data['signature_hex'])
    public_key_bytes = bytes.fromhex(sig_data['public_key_hex'])

    try:
        public_key = ed25519.Ed25519PublicKey.from_public_bytes(public_key_bytes)
    except Exception:
        return {'status': 'REJECTED', 'reason': '[FAIL] Invalid public key format.'}

    payload_bytes = json.dumps(payload, sort_keys=True, separators=(',', ':')).encode('utf-8')
    try:
        public_key.verify(signature_bytes, payload_bytes)
    except Exception:
        return {'status': 'REJECTED', 'reason': '[FAIL] 1. Signature is INVALID.'}

    auth_key = None
    for k in registry.get('keys', []):
        if k['public_key_hex'] == sig_data['public_key_hex']:
            auth_key = k
            break

    if not auth_key:
        return {'status': 'REJECTED', 'reason': '[FAIL] 2. Unauthorized Key.'}

    for rk in revocation.get('revoked_keys', []):
        if rk['key_id'] == auth_key['key_id']:
            if payload['timestamp'] <= rk['revocation_time']:
                pass 
            else:
                return {'status': 'REJECTED', 'reason': '[FAIL] 3. Key REVOKED.'}

    if payload.get('package_id') != 'EVIDENCE-001':
        return {'status': 'REJECTED', 'reason': '[FAIL] 4. Replay Attack.'}

    return {'status': 'VERIFIED', 'reason': '[PASS] The evidence package is fully authenticated.'}

@app.get('/', response_class=HTMLResponse)
async def index(request: Request):
    if not request.session.get('user'):
        return RedirectResponse(url='/login')
    return RedirectResponse(url='/dashboard')

@app.get('/login', response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse(request=request, name='login.html')

@app.post('/login')
async def login(request: Request, password: str = Form(...)):
    if password == 'admin': 
        request.session['user'] = 'admin'
        return RedirectResponse(url='/dashboard', status_code=303)
    return templates.TemplateResponse(request=request, name='login.html', context={'error': 'Invalid password'})

@app.get('/dashboard', response_class=HTMLResponse)
async def dashboard(request: Request):
    if not request.session.get('user'):
        return RedirectResponse(url='/login')
    return templates.TemplateResponse(request=request, name='dashboard.html')

@app.post('/dashboard/verify')
async def dashboard_verify(request: Request):
    if not request.session.get('user'):
        return RedirectResponse(url='/login')
    
    try:
        with open(r'SIGNATURE-001.json', 'r') as f:
            sig_data = json.load(f)
        with open(r'KEY-REGISTRY-001.json', 'r') as f:
            registry = json.load(f)
        with open(r'REVOCATION-001.json', 'r') as f:
            revocation = json.load(f)
    except Exception as e:
        return templates.TemplateResponse(request=request, name='dashboard.html', context={'error': 'Failed to load JSON files on server.'})

    result = run_verification(sig_data, registry, revocation)
    return templates.TemplateResponse(request=request, name='dashboard.html', context={'result': result})
@app.post('/api/v1/verify')
def api_verify(request: Request, payload: dict):
    api_key = request.headers.get('X-API-Key')
    if api_key not in VALID_API_KEYS:
        raise HTTPException(status_code=401, detail='Invalid API Key.')
    
    result = run_verification(payload['signature_data'], payload['registry'], payload['revocation'])
    return result