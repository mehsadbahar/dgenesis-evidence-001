﻿import json
from cryptography.hazmat.primitives import serialization

# بارگذاری کلید خصوصی
with open("E:\\private_key.pem", "rb") as f:
    private_key = serialization.load_pem_private_key(f.read(), password=None)

# ساختار Payload
payload = {
    "package_id": "EVIDENCE-001",
    "protocol_version": "1.0.0",
    "seal_hash": "8fa8fcc75e6b9e38e93aed3f6e13cd63eda8fe17e2a25e9f2040e9e519be9a6d",
    "signer_id": "Mehdi Sadegh Baharvand",
    "timestamp": "2026-11-15T12:00:00Z",
    "algorithm": "Ed25519"
}

# Canonicalization (مرتب‌سازی الفبایی و حذف فاصله‌ها)
payload_bytes = json.dumps(payload, sort_keys=True, separators=(',', ':')).encode('utf-8')

# امضا
signature = private_key.sign(payload_bytes)

# استخراج کلید عمومی به فرمت Hex برای قرار دادن در فایل
public_key = private_key.public_key()
public_key_bytes = public_key.public_bytes(
    encoding=serialization.Encoding.Raw,
    format=serialization.PublicFormat.Raw
)

# ساخت فایل نهایی امضا
sig_data = {
    "payload": payload,
    "signature_hex": signature.hex(),
    "public_key_hex": public_key_bytes.hex()
}

with open("E:\\SIGNATURE-001.json", "w") as f:
    json.dump(sig_data, f, indent=4)

print("Package SIGNED successfully. File: E:\\SIGNATURE-001.json")