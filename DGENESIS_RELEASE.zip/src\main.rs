use sha2::{Digest, Sha256};
use std::collections::HashMap;
use std::fmt::Write as _;

struct Row {
    id: &'static str,
    approval: &'static str,
    payload: &'static str,
}

fn canonical_input(id: &str, payload: &str, prev: &str) -> String {
    format!("id={}|payload={}|prev={}", id, payload, prev)
}

fn sha256_hex(input: &str) -> (String, usize) {
    let bytes = input.as_bytes();
    let mut h = Sha256::new();
    h.update(bytes);
    let digest = h.finalize();
    let mut hex = String::with_capacity(64);
    for b in digest {
        write!(&mut hex, "{:02x}", b).unwrap();
    }
    (hex, bytes.len())
}

fn main() {
    let rows = vec![
        Row { id: "E-1", approval: "APPROVED",   payload: "E1_PAYLOAD_V1" },
        Row { id: "E-2", approval: "APPROVED",   payload: "E2_PAYLOAD_V1" },
        Row { id: "E-3", approval: "APPROVED",   payload: "E3_PAYLOAD_V1" },
        Row { id: "E-4", approval: "APPROVED",   payload: "E4_PAYLOAD_V1" },
        Row { id: "E-5", approval: "APPROVED",   payload: "E5_PAYLOAD_V1" },
        Row { id: "E-6", approval: "APPROVED",   payload: "E6_PAYLOAD_V1" },
        Row { id: "H-1", approval: "HYPOTHESIS", payload: "H1_PAYLOAD_V1" },
    ];

    const GENESIS_PREV: &str = "GENESIS";
    let mut records: Vec<(&str, &str, &str, String, String, usize, String)> = Vec::new();
    let mut prev = GENESIS_PREV.to_string();

    for r in &rows {
        let input = canonical_input(r.id, r.payload, &prev);
        let (hash, blen) = sha256_hex(&input);
        records.push((r.id, r.approval, r.payload, prev.clone(), input, blen, hash.clone()));
        prev = hash;
    }

    println!("=== DGENESIS CHAIN RAW STDOUT ===");
    println!("ALG=SHA-256");
    println!("CANONICAL_FORMAT=id=<id>|payload=<payload>|prev=<prev_hash>");
    println!("GENESIS_PREV={}", GENESIS_PREV);
    for (id, ap, _pl, ph, inp, bl, h) in &records {
        println!("---");
        println!("ID={}", id);
        println!("APPROVAL_STATUS={}", ap);
        println!("PREV_HASH={}", ph);
        println!("INPUT_STRING={}", inp);
        println!("INPUT_BYTE_LEN={}", bl);
        println!("HASH={}", h);
    }

    println!("=== PREV_HASH VALIDATION ===");
    let mut chain_ok = true;
    let mut expected = GENESIS_PREV.to_string();
    for (id, _ap, _pl, ph, _inp, _bl, h) in &records {
        let ok = ph == &expected;
        println!("{}: prev_ok={}", id, ok);
        if !ok { chain_ok = false; }
        expected = h.clone();
    }
    println!("CHAIN_VALID={}", chain_ok);

    println!("=== TAMPER TEST (E-3 payload mutated) ===");
    let mut tampered: HashMap<&str, String> = HashMap::new();
    let mut p = GENESIS_PREV.to_string();
    for (id, _ap, payload, _ph, _inp, _bl, _h) in &records {
        let pay = if *id == "E-3" { "E3_PAYLOAD_X" } else { payload };
        let inp = canonical_input(id, pay, &p);
        let (h, _) = sha256_hex(&inp);
        tampered.insert(id, h.clone());
        p = h;
    }
    for (id, _ap, _pl, _ph, _inp, _bl, h) in &records {
        let t = tampered.get(id).unwrap();
        println!("{}: tampered_diverged={}", id, t != h);
    }

    println!("=== EVIDENCE STATUS ===");
    println!("EVIDENCE-001=EXECUTED (pending independent VERIFIED)");
    println!("H-1=HYPOTHESIS (hash execution does NOT promote to ACTUAL)");

    if !chain_ok { std::process::exit(2); }
}