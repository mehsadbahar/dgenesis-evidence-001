﻿import json
import sys
from cryptography.hazmat.primitives.asymmetric import ed25519

print("=== RUNNING VERIFY-002 (FULL TRUST CHAIN) ===")

with open("E:\\SIGNATURE-001.json", "r") as f:
    sig_data = json.load(f)
with open("E:\\KEY-REGISTRY-001.json", "r") as f:
    registry = json.load(f)
with open("E:\\REVOCATION-001.json", "r") as f:
    revocation = json.load(f)

payload = sig_data["payload"]
signature_bytes = bytes.fromhex(sig_data["signature_hex"])
public_key_bytes = bytes.fromhex(sig_data["public_key_hex"])
public_key = ed25519.Ed25519PublicKey.from_public_bytes(public_key_bytes)

# ۱. بررسی امضای دیجیتال
payload_bytes = json.dumps(payload, sort_keys=True, separators=(',', ':')).encode('utf-8')
try:
    public_key.verify(signature_bytes, payload_bytes)
    print("[PASS] 1. Signature is cryptographically VALID.")
except Exception:
    print("[FAIL] 1. Signature is INVALID. Tampering detected.")
    print("\n[REJECTED] The evidence package is invalid.")
    sys.exit(1)

# ۲. بررسی مجاز بودن کلید
auth_key = None
for k in registry["keys"]:
    if k["public_key_hex"] == sig_data["public_key_hex"]:
        auth_key = k
        break

if not auth_key:
    print("[FAIL] 2. Public key not found in Trust Registry (Unauthorized Signer).")
    print("\n[REJECTED] The evidence package is invalid.")
    sys.exit(1)
print("[PASS] 2. Key is authorized and belongs to: " + auth_key["owner"])

# ۳. بررسی ابطال کلید (با اصلاح باگ)
is_revoked = False
for rk in revocation["revoked_keys"]:
    if rk["key_id"] == auth_key["key_id"]:
        if payload["timestamp"] <= rk["revocation_time"]:
            print("[PASS] 3. Key was revoked, but Signature_Time <= Revocation_Time (Historical Signature is VALID).")
        else:
            print("[FAIL] 3. Key was REVOKED at " + rk["revocation_time"] + ". Signature is Unauthorized!")
            is_revoked = True
        break
if not is_revoked and len(revocation["revoked_keys"]) == 0:
    print("[PASS] 3. Key is NOT revoked.")

if is_revoked:
    print("\n[REJECTED] The evidence package is invalid (Unauthorized Signer).")
    sys.exit(1)

# ۴. بررسی حمله بازپخش
expected_package_id = "EVIDENCE-001"
if payload["package_id"] != expected_package_id:
    print("[FAIL] 4. Replay Attack Detected! Package ID mismatch.")
    print("\n[REJECTED] The evidence package is invalid.")
    sys.exit(1)
print("[PASS] 4. Package ID matches (No Replay Attack).")

print("\n[VERIFIED] The evidence package is fully authenticated and trusted.")